package com.org.student_controller;

public class ViewAllStudent {

}
